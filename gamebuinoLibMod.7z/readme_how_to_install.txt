1. Uncompress "Gamebuino.7z". All uncompressed files shoud be in folder "Gamebuino". 
2. Copy "Gamebuino" folder to arduino library folder.